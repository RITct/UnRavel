<?php
$result = mysqli_connect("localhost","thampichayan","123decipher123","decipher16");
?>
