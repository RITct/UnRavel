<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Unravel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/adstyle.css">
  <style>

  </style>
  </head>

  <body style="background-image:url('imgs/4343.jpg')">

    <div id="header">
  
  <nav>
    <ul>
	 <li>
        <a href="adleader.php">Users</a>        
      </li>
      <li>
        <a href="shakthiman.php?work=1">user answer logs</a>       
      </li>
      <li>
        <a href="shakthiman.php?work=2">add/edit Levels</a>
      </li>
	  <li>
        <a href="shakthiman.php?work=4">view Levels</a>
      </li>
      <li>
        <a href="logout.php">Logout</a>
      </li>
    </ul>
  </nav>
</div>
<div>
  
  </div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
